package my.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import my.model.Person;

public class PersonDao {
	
	public int insert(Connection conn, Person person) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement
					("insert into person (name, "
							+ "address, age, registerTime) values (?,?,?,?)");
			pstmt.setString(1, person.getName());
			pstmt.setString(2, person.getAddress());
			pstmt.setInt(3, person.getAge());
			pstmt.setTimestamp(4, 
					new Timestamp(person.getRegisterTime().getTime()));
			return pstmt.executeUpdate();
		} finally {
			pstmt.close();
		}
	}
	
	public int update(Connection conn, Person person) throws SQLException {
		PreparedStatement pstmt = null;
		try {
			pstmt = conn.prepareStatement
			("update person set name=?, address=?, "
					+ "age=?, registerTime=? where id =?");
			pstmt.setString(1, person.getName());
			pstmt.setString(2, person.getAddress());
			pstmt.setInt(3, person.getAge());
			pstmt.setTimestamp(4, 
					new Timestamp(person.getRegisterTime().getTime()));
			pstmt.setInt(5, person.getId());
			return pstmt.executeUpdate();
		} finally {
			pstmt.close();
		}
	}
	
	public Person select(Connection conn, int id) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;  //db에서 읽어온 레코드를 저장하는 객체
		try {
			pstmt = conn.prepareStatement
					("select * from person where id = ?");
			pstmt.setInt(1, id);
			rs = pstmt.executeQuery();
			if (rs.next()){
				return makePersonFromRS(rs);
			} else {
				return null;
			}
		} finally {
			pstmt.close(); rs.close();
		}
	}
	public Person makePersonFromRS(ResultSet rs) throws SQLException{
		Person person = new Person();
		person.setId(rs.getInt("id"));
		person.setName(rs.getString("name"));
		person.setAddress(rs.getString("address"));
		person.setAge(rs.getInt("age"));
		person.setRegisterTime(rs.getTimestamp("registerTime"));
		return person;
	}

	public int delete(Connection conn, int id) throws SQLException {
		PreparedStatement pstmt = null; 
		try {
			pstmt = conn.prepareStatement("delete from person where id=?");
			pstmt.setInt(1, id);
			return pstmt.executeUpdate();
		} finally {
			pstmt.close();
		}
	}
	
	public List<Person> selectList(Connection conn) throws SQLException{
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		try {
			pstmt = conn.prepareStatement("select * from person");
			rs = pstmt.executeQuery();
			if (rs.next()){
				List<Person> personList = new ArrayList<Person>();
				do {
					personList.add(makePersonFromRS(rs));
				} while (rs.next());
				return personList;
			} else {
				return null;
			}
		} finally {
			rs.close();
			pstmt.close();
		}
	}
}









